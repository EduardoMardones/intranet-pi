// ======================================================
// PÁGINA ADMIN: Aprobar/Rechazar Solicitudes
// Ubicación: src/pages/admin/AprobacionesAdminPage.tsx
// Descripción: Panel para gestionar solicitudes pendientes
// ======================================================

'use client';

import React, { useState, useEffect } from 'react';
import { UnifiedNavbar } from '@/components/common/layout/UnifiedNavbar';
import Footer from '@/components/common/layout/Footer';
import Banner from '@/components/common/layout/Banner';
import bannerSolicitudes from '@/components/images/banner_images/BannerSolicitudes.png';
import {
  CalendarDays,
  CheckCircle,
  XCircle,
  Clock,
  User,
  FileText,
  Download,
  Filter,
  AlertCircle,
  Send
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/common/multiusos/textarea';
import { useAuth } from '@/api/contexts/AuthContext';
import { solicitudService } from '@/api';
import type { Solicitud, TipoSolicitud } from '@/api';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// ======================================================
// UTILIDADES
// ======================================================

const formatearFecha = (fecha: string): string => {
  return new Date(fecha).toLocaleDateString('es-CL', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });
};

const getTipoBadge = (tipo: TipoSolicitud) => {
  return tipo === 'VACACIONES' ? (
    <Badge className="bg-blue-100 text-blue-800 border-blue-200 border">
      Vacaciones
    </Badge>
  ) : (
    <Badge className="bg-purple-100 text-purple-800 border-purple-200 border">
      Días Administrativos
    </Badge>
  );
};

// ======================================================
// COMPONENTE PRINCIPAL
// ======================================================

export const AprobacionesAdminPage: React.FC = () => {
  const { user } = useAuth();

  // Estados
  const [solicitudes, setSolicitudes] = useState<Solicitud[]>([]);
  const [filteredSolicitudes, setFilteredSolicitudes] = useState<Solicitud[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string>('');

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'aprobar' | 'rechazar'>('aprobar');
  const [selectedSolicitud, setSelectedSolicitud] = useState<Solicitud | null>(null);
  const [comentario, setComentario] = useState('');
  const [processing, setProcessing] = useState(false);

  // Filtros
  const [filtroTipo, setFiltroTipo] = useState<TipoSolicitud | 'TODOS'>('TODOS');
  const [filtroArea, setFiltroArea] = useState<string>('TODOS');

  // ======================================================
  // EFECTOS
  // ======================================================

  useEffect(() => {
    if (user?.id) {
      cargarSolicitudes();
    }
  }, [user]);

  useEffect(() => {
    aplicarFiltros();
  }, [solicitudes, filtroTipo, filtroArea]);

  // ======================================================
  // FUNCIONES
  // ======================================================

  const cargarSolicitudes = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await solicitudService.getPendientes();
      // Ordenar por fecha de creación (más antigua primero)
      const ordenadas = data.sort((a, b) => 
        new Date(a.creada_en).getTime() - new Date(b.creada_en).getTime()
      );
      setSolicitudes(ordenadas);
    } catch (err: any) {
      console.error('Error al cargar solicitudes:', err);
      setError('No se pudieron cargar las solicitudes pendientes. Intenta nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  const aplicarFiltros = () => {
    let resultado = [...solicitudes];

    if (filtroTipo !== 'TODOS') {
      resultado = resultado.filter(s => s.tipo === filtroTipo);
    }

    if (filtroArea !== 'TODOS') {
      resultado = resultado.filter(s => s.usuario_area === filtroArea);
    }

    setFilteredSolicitudes(resultado);
  };

  const abrirModal = (solicitud: Solicitud, tipo: 'aprobar' | 'rechazar') => {
    setSelectedSolicitud(solicitud);
    setModalType(tipo);
    setComentario('');
    setModalOpen(true);
  };

  const cerrarModal = () => {
    setModalOpen(false);
    setSelectedSolicitud(null);
    setComentario('');
  };

  const handleAprobar = async () => {
    if (!selectedSolicitud) return;

    setProcessing(true);

    try {
      await solicitudService.aprobar(selectedSolicitud.id, {
        comentario_aprobacion: comentario.trim() || undefined
      });

      setSuccessMessage(`Solicitud de ${selectedSolicitud.usuario_nombre} aprobada exitosamente`);
      await cargarSolicitudes();
      cerrarModal();

      setTimeout(() => setSuccessMessage(''), 5000);
    } catch (err: any) {
      console.error('Error al aprobar solicitud:', err);
      setError(err.response?.data?.message || 'Error al aprobar la solicitud');
      setTimeout(() => setError(''), 5000);
    } finally {
      setProcessing(false);
    }
  };

  const handleRechazar = async () => {
    if (!selectedSolicitud) return;

    if (!comentario.trim()) {
      setError('Debes proporcionar un motivo para rechazar la solicitud');
      setTimeout(() => setError(''), 3000);
      return;
    }

    setProcessing(true);

    try {
      await solicitudService.rechazar(selectedSolicitud.id, {
        comentario_aprobacion: comentario.trim()
      });

      setSuccessMessage(`Solicitud de ${selectedSolicitud.usuario_nombre} rechazada`);
      await cargarSolicitudes();
      cerrarModal();

      setTimeout(() => setSuccessMessage(''), 5000);
    } catch (err: any) {
      console.error('Error al rechazar solicitud:', err);
      setError(err.response?.data?.message || 'Error al rechazar la solicitud');
      setTimeout(() => setError(''), 5000);
    } finally {
      setProcessing(false);
    }
  };

  const descargarArchivo = (archivoPath: string) => {
    const url = solicitudService.getArchivoUrl(archivoPath);
    window.open(url, '_blank');
  };

  // ======================================================
  // ÁREAS ÚNICAS (para filtro)
  // ======================================================

  const areasUnicas = Array.from(new Set(solicitudes.map(s => s.usuario_area)));

  // ======================================================
  // RENDER
  // ======================================================

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <UnifiedNavbar />
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <p className="text-gray-500">Debes iniciar sesión</p>
        </div>
        <Footer />
      </div>
    );
  }

  // Verificar permisos
  if (!user.rol_puede_aprobar_solicitudes) {
    return (
      <div className="min-h-screen bg-gray-50">
        <UnifiedNavbar />
        <Banner title="Aprobaciones" imageSrc={bannerSolicitudes} />
        <div className="flex items-center justify-center h-[calc(100vh-300px)]">
          <Alert className="max-w-md bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              No tienes permisos para aprobar solicitudes.
            </AlertDescription>
          </Alert>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <UnifiedNavbar />
      <Banner title="Gestión de Solicitudes" imageSrc={bannerSolicitudes} />

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Mensajes */}
        {successMessage && (
          <Alert className="mb-6 bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              {successMessage}
            </AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert className="mb-6 bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Estadísticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Pendientes</p>
                <p className="text-3xl font-bold text-gray-800">{solicitudes.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <CalendarDays className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Vacaciones</p>
                <p className="text-3xl font-bold text-gray-800">
                  {solicitudes.filter(s => s.tipo === 'VACACIONES').length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-100 rounded-lg">
                <FileText className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">Días Admin.</p>
                <p className="text-3xl font-bold text-gray-800">
                  {solicitudes.filter(s => s.tipo === 'ADMINISTRATIVO').length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Filtros */}
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <span className="text-sm font-semibold text-gray-700">Filtros:</span>
            </div>

            <Select value={filtroTipo} onValueChange={(value: any) => setFiltroTipo(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODOS">Todos los tipos</SelectItem>
                <SelectItem value="VACACIONES">Vacaciones</SelectItem>
                <SelectItem value="ADMINISTRATIVO">Días Admin.</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filtroArea} onValueChange={setFiltroArea}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Área" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODOS">Todas las áreas</SelectItem>
                {areasUnicas.map(area => (
                  <SelectItem key={area} value={area}>{area}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="ml-auto text-sm text-gray-500">
              {filteredSolicitudes.length} solicitud(es)
            </div>
          </div>
        </div>

        {/* Lista de solicitudes */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-[#52FFB8]"></div>
            <p className="text-gray-500 mt-4">Cargando solicitudes...</p>
          </div>
        ) : filteredSolicitudes.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">
              {solicitudes.length === 0 
                ? '¡Excelente! No hay solicitudes pendientes'
                : 'No hay solicitudes que coincidan con los filtros'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredSolicitudes.map((solicitud) => (
              <div key={solicitud.id} className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${
                      solicitud.tipo === 'VACACIONES' ? 'bg-blue-50' : 'bg-purple-50'
                    }`}>
                      <CalendarDays className={`w-6 h-6 ${
                        solicitud.tipo === 'VACACIONES' ? 'text-blue-500' : 'text-purple-500'
                      }`} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        {getTipoBadge(solicitud.tipo)}
                        <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200 border flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Pendiente
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500">
                        Solicitado el {formatearFecha(solicitud.creada_en)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Información del solicitante */}
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <div className="flex items-center gap-2 mb-3">
                    <User className="w-4 h-4 text-gray-400" />
                    <p className="text-xs text-gray-500 font-semibold">SOLICITANTE</p>
                  </div>
                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Nombre</p>
                      <p className="font-semibold text-gray-800">{solicitud.usuario_nombre}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Cargo</p>
                      <p className="font-semibold text-gray-800">{solicitud.usuario_cargo}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Área</p>
                      <p className="font-semibold text-gray-800">{solicitud.usuario_area}</p>
                    </div>
                  </div>
                </div>

                {/* Detalles de la solicitud */}
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Período Solicitado</p>
                    <p className="font-semibold text-gray-800">
                      {formatearFecha(solicitud.fecha_inicio)}
                    </p>
                    <p className="font-semibold text-gray-800">
                      hasta {formatearFecha(solicitud.fecha_fin)}
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      {solicitud.dias_solicitados} día(s) hábil(es)
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">Motivo</p>
                    <p className="text-sm text-gray-700">{solicitud.motivo}</p>
                  </div>
                </div>

                {/* Archivo adjunto */}
                {solicitud.archivo_adjunto && (
                  <div className="mb-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => descargarArchivo(solicitud.archivo_adjunto!)}
                      className="text-[#52FFB8] hover:bg-[#52FFB8] hover:text-gray-900"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Ver archivo adjunto
                    </Button>
                  </div>
                )}

                {/* Acciones */}
                <div className="flex gap-3 pt-4 border-t">
                  <Button
                    onClick={() => abrirModal(solicitud, 'aprobar')}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Aprobar
                  </Button>

                  <Button
                    onClick={() => abrirModal(solicitud, 'rechazar')}
                    variant="outline"
                    className="flex-1 text-red-600 border-red-600 hover:bg-red-50"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Rechazar
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal de confirmación */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {modalType === 'aprobar' ? 'Aprobar Solicitud' : 'Rechazar Solicitud'}
            </DialogTitle>
            <DialogDescription>
              {selectedSolicitud && (
                <>
                  Solicitud de <strong>{selectedSolicitud.usuario_nombre}</strong>
                  <br />
                  {selectedSolicitud.tipo === 'VACACIONES' ? 'Vacaciones' : 'Días Administrativos'}
                  {' '}del {formatearFecha(selectedSolicitud.fecha_inicio)} al{' '}
                  {formatearFecha(selectedSolicitud.fecha_fin)}
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="py-4">
            <Label className="text-gray-700 font-semibold mb-2 block">
              Comentario {modalType === 'rechazar' ? '(Obligatorio)' : '(Opcional)'}
            </Label>
            <Textarea
              value={comentario}
              onChange={(e) => setComentario(e.target.value)}
              placeholder={
                modalType === 'aprobar'
                  ? 'Agrega un comentario adicional (opcional)'
                  : 'Explica el motivo del rechazo'
              }
              rows={4}
              className={modalType === 'rechazar' && !comentario.trim() ? 'border-red-500' : ''}
            />
            {modalType === 'rechazar' && !comentario.trim() && (
              <p className="text-xs text-red-500 mt-1">
                Debes proporcionar un motivo para rechazar
              </p>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={cerrarModal}
              disabled={processing}
            >
              Cancelar
            </Button>

            <Button
              onClick={modalType === 'aprobar' ? handleAprobar : handleRechazar}
              disabled={processing || (modalType === 'rechazar' && !comentario.trim())}
              className={
                modalType === 'aprobar'
                  ? 'bg-green-600 hover:bg-green-700'
                  : 'bg-red-600 hover:bg-red-700'
              }
            >
              {processing ? (
                'Procesando...'
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  {modalType === 'aprobar' ? 'Aprobar' : 'Rechazar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  );
};

export default AprobacionesAdminPage;