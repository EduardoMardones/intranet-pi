// ======================================================
// SERVICIO: SolicitudService
// Ubicación: frontend/src/api/services/solicitudService.ts
// Descripción: Gestión de solicitudes de vacaciones y días administrativos
// ======================================================

import axios from '../axios';

// ======================================================
// TIPOS
// ======================================================

export type TipoSolicitud = 'VACACIONES' | 'ADMINISTRATIVO';
export type EstadoSolicitud = 'PENDIENTE' | 'APROBADA' | 'RECHAZADA' | 'CANCELADA';

export interface Solicitud {
  id: string;
  
  // Relaciones
  usuario: string;  // UUID
  usuario_nombre: string;
  usuario_email: string;
  usuario_cargo: string;
  usuario_area: string;
  
  aprobador: string | null;
  aprobador_nombre: string | null;
  
  // Información de la solicitud
  tipo: TipoSolicitud;
  fecha_inicio: string;  // YYYY-MM-DD
  fecha_fin: string;     // YYYY-MM-DD
  dias_solicitados: number;
  motivo: string;
  
  // Estado
  estado: EstadoSolicitud;
  fecha_aprobacion: string | null;
  comentario_aprobacion: string | null;
  
  // Adjuntos (opcional)
  archivo_adjunto: string | null;
  
  // Auditoría
  creada_en: string;
  actualizada_en: string;
}

export interface CrearSolicitudDTO {
  tipo: TipoSolicitud;
  fecha_inicio: string;
  fecha_fin: string;
  motivo: string;
  archivo_adjunto?: File;  // Para subir archivo
}

export interface AprobarRechazarDTO {
  estado: 'APROBADA' | 'RECHAZADA';
  comentario_aprobacion?: string;
}

export interface EstadisticasSolicitudes {
  total: number;
  pendientes: number;
  aprobadas: number;
  rechazadas: number;
  vacaciones_usadas: number;
  administrativos_usados: number;
  vacaciones_disponibles: number;
  administrativos_disponibles: number;
}

// ======================================================
// SERVICIO
// ======================================================

class SolicitudService {
  private readonly baseURL = '/solicitudes';

  /**
   * Obtener todas las solicitudes (admin)
   */
  async getAll(params?: {
    usuario?: string;
    tipo?: TipoSolicitud;
    estado?: EstadoSolicitud;
    fecha_inicio?: string;
    fecha_fin?: string;
  }): Promise<Solicitud[]> {
    const response = await axios.get(`${this.baseURL}/`, { params });
    return response.data;
  }

  /**
   * Obtener solicitud por ID
   */
  async getById(id: string): Promise<Solicitud> {
    const response = await axios.get(`${this.baseURL}/${id}/`);
    return response.data;
  }

  /**
   * Obtener mis solicitudes (usuario actual)
   */
  async getMisSolicitudes(params?: {
    tipo?: TipoSolicitud;
    estado?: EstadoSolicitud;
  }): Promise<Solicitud[]> {
    const response = await axios.get(`${this.baseURL}/mis_solicitudes/`, { params });
    return response.data;
  }

  /**
   * Crear nueva solicitud
   */
  async create(data: CrearSolicitudDTO): Promise<Solicitud> {
    // Si hay archivo adjunto, usar FormData
    if (data.archivo_adjunto) {
      const formData = new FormData();
      formData.append('tipo', data.tipo);
      formData.append('fecha_inicio', data.fecha_inicio);
      formData.append('fecha_fin', data.fecha_fin);
      formData.append('motivo', data.motivo);
      formData.append('archivo_adjunto', data.archivo_adjunto);

      const response = await axios.post(`${this.baseURL}/`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    }

    // Sin archivo adjunto
    const response = await axios.post(`${this.baseURL}/`, data);
    return response.data;
  }

  /**
   * Aprobar solicitud (admin/jefe)
   */
  async aprobar(id: string, data?: { comentario_aprobacion?: string }): Promise<Solicitud> {
    const response = await axios.post(`${this.baseURL}/${id}/aprobar/`, data || {});
    return response.data;
  }

  /**
   * Rechazar solicitud (admin/jefe)
   */
  async rechazar(id: string, data: { comentario_aprobacion: string }): Promise<Solicitud> {
    const response = await axios.post(`${this.baseURL}/${id}/rechazar/`, data);
    return response.data;
  }

  /**
   * Cancelar solicitud (usuario)
   */
  async cancelar(id: string): Promise<Solicitud> {
    const response = await axios.post(`${this.baseURL}/${id}/cancelar/`);
    return response.data;
  }

  /**
   * Obtener solicitudes pendientes (para aprobar)
   */
  async getPendientes(): Promise<Solicitud[]> {
    return this.getAll({ estado: 'PENDIENTE' });
  }

  /**
   * Obtener estadísticas de solicitudes del usuario actual
   */
  async getEstadisticas(): Promise<EstadisticasSolicitudes> {
    const response = await axios.get(`${this.baseURL}/estadisticas/`);
    return response.data;
  }

  /**
   * Calcular días entre dos fechas (excluyendo fines de semana)
   */
  calcularDiasHabiles(fechaInicio: string, fechaFin: string): number {
    const inicio = new Date(fechaInicio);
    const fin = new Date(fechaFin);
    let dias = 0;

    for (let d = new Date(inicio); d <= fin; d.setDate(d.getDate() + 1)) {
      const diaSemana = d.getDay();
      // 0 = Domingo, 6 = Sábado
      if (diaSemana !== 0 && diaSemana !== 6) {
        dias++;
      }
    }

    return dias;
  }

  /**
   * Validar que las fechas no se superpongan con otras solicitudes
   */
  async validarFechas(fechaInicio: string, fechaFin: string): Promise<{
    valido: boolean;
    mensaje?: string;
  }> {
    try {
      const response = await axios.post(`${this.baseURL}/validar_fechas/`, {
        fecha_inicio: fechaInicio,
        fecha_fin: fechaFin,
      });
      return response.data;
    } catch (error: any) {
      return {
        valido: false,
        mensaje: error.response?.data?.message || 'Error al validar fechas',
      };
    }
  }

  /**
   * Descargar archivo adjunto
   */
  getArchivoUrl(archivoPath: string): string {
    return `${axios.defaults.baseURL}${archivoPath}`;
  }
}

// ======================================================
// EXPORT
// ======================================================

export const solicitudService = new SolicitudService();
export default solicitudService;